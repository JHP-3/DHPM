from . import resnet_clip
